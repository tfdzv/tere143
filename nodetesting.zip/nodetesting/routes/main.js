module.exports = function (app, appData) {

    // handle routes

    // home page
    app.get('/', function (req, res) {
        console.log("Currently on: Index page....")
        res.render('index.ejs', appData)
    });
    //about page
    app.get('/about', function(req, res) {
        res.render('about.ejs', appData)
      });
      
    // menu page
    app.get('/menus', function (req, res) {
        console.log("Currently on: Menu page");

        // declare sqlquery > normal (no filter)
        let sqlquery = `SELECT      item_name, item_description
                        FROM        restaurant_menu1`;

        let selected = req.query.allergens;

        // declare que for filtered query
        let que = "SELECT  *  FROM  menu_allergens1  JOIN  restaurant_menu1  ON  menu_allergens1.item_id = restaurant_menu1.item_id";
        // if selected, replace sqlquery = ""; then sqlquery = que; then that is the data
        if (selected) {
            que += ` WHERE allergen NOT LIKE '%${selected.join("%' AND allergen NOT LIKE '%")}%';`;
            sqlquery = "";
            sqlquery = que;
        }
        db.query(sqlquery, (err, result) => {
            let data = Object.assign({}, appData, {
                restaurant_menu: JSON.parse(JSON.stringify(result)),
                selectedAllergens: selected
            });
            res.render('menus.ejs', data);
        });
    });
    // ==== INDIVIDUAL MENUS ====

    // wakey wakey
    app.get('/wakey', function (req, res) {
        let sqlquery = `SELECT      item_name, item_description
                        FROM        restaurant_menu1
                        WHERE       restaurant_id=1;`

        db.query(sqlquery, (err, result) => {
            let data = Object.assign({}, appData, {
                restaurant_menu: result
            });
            console.log(data);
            res.render('wakey.ejs', data);
        });
    });

    // student union
    app.get('/su', function (req, res) {
        let sqlquery = `SELECT      item_name, item_description
                        FROM        restaurant_menu1
                        WHERE       restaurant_id=4;`

        db.query(sqlquery, (err, result) => {
            let data = Object.assign({}, appData, {
                restaurant_menu: JSON.parse(JSON.stringify(result))
            });
            console.log(data);
            res.render('su.ejs', data);
        });
    });

    // Cafe 35
    app.get('/thirtyfive', function (req, res) {
        let sqlquery = `SELECT      item_name, item_description
                        FROM        restaurant_menu1
                        WHERE       restaurant_id=2;`

        db.query(sqlquery, (err, result) => {
            let data = Object.assign({}, appData, {
                restaurant_menu: JSON.parse(JSON.stringify(result))
            });
            console.log(data);
            res.render('thirtyfive.ejs', data);
        });
    });

    // RHB Refectory
    app.get('/refectory', function (req, res) {
        let sqlquery = `SELECT      item_name, item_description
                        FROM        restaurant_menu1
                        WHERE       restaurant_id=3;`

        db.query(sqlquery, (err, result) => {
            let data = Object.assign({}, appData, {
                restaurant_menu: JSON.parse(JSON.stringify(result))
            });
            console.log(data);
            res.render('refectory.ejs', data);
        });
    });
}
